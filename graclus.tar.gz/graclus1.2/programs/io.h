int readClustering(char *, int *, int);
void WriteCoarsestGraph(GraphType *graph, char *filename, int *wgtflag);
void ReadCoarsestInit(GraphType *graph, char *filename, int *wgtflag);
void ReadGraph(GraphType *graph, char *filename, int *wgtflag);
